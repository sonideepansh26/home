/*package com.cg.mobile.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.dto.Mobiles;

public class DataValidator {

	public boolean validateInput(PurchaseDetails p){
		if(validateId(p.getCname()) 
		   && validateEmail(p.getMailId())
		   &&validatePhoneno(p.getPhoneNo())
		   &&validateMobileId(p.getMobileId())
		   )
		return true;
		else
		return false;
	}
	public boolean validateId(String cname){
		Pattern pattern= Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher mat= pattern.matcher(cname);
		if(mat.matches())
			return true;
		else
			return false;
		
	}
	public boolean validateEmail(String email){
		//Pattern pattern= Pattern.compile("[a-z0-9]*@[a-z].com");
		Pattern pattern= Pattern.compile("[a-z0-9]*@capgemini.com");
		Matcher mat= pattern.matcher(email);
		if(mat.matches())
			return true;
		else
			return false;
	}
	public boolean validatePhoneno(String phoneno){
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher mat= pattern.matcher(phoneno);
		if(mat.matches())
			return true;
		else
			return false;
	}
	public boolean validateMobileId(int i){
		String str=Integer.toString(i);
		Pattern pattern= Pattern.compile("[0-9]{4}");
		Matcher mat= pattern.matcher(str);
		if(mat.matches())
			return true;
		else
			return false;
	}
}
*/