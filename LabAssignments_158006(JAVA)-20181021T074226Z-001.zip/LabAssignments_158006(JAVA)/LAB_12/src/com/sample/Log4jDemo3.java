package com.sample;
import com.sample.bean.Message;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.PropertyConfigurator;

import org.apache.log4j.Logger;

public class Log4jDemo3 {
    static Logger logger=Logger.getLogger(Log4jDemo3.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
      Message m=new Message();
      m.setMessage(null);
      
     
      System.out.println(m.getMessage());
      logger.info("This is info level msg");
		logger.debug("This is debug level message");
		logger.error("This is error level message");
		logger.warn("This is warn level message");
		logger.fatal("This is fatal level message");
		
		System.out.println("messages logged to file :basic.log");
   
      
	}

}
