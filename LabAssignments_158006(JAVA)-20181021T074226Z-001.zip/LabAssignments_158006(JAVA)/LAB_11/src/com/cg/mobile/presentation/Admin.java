package com.cg.mobile.presentation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;



//logger import
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
//logger import close
import com.cg.mobile.dto.Mobiles;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;
//import com.cg.mobile.validation.DataValidator;

public class Admin {
	
	//Main Method
	
	public static void main(String[] args) {
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("./resources/log4j.properties");
	PurchaseDetails purchase=new PurchaseDetails();
	IMobileService service=new MobileServiceImpl();
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter choice : \n1. Purchase Details \n2. Update Mobiles \n3. View Details of Mobiles\n4. Delete Mobiles \n5. Search Mobiles");
	int ch=sc.nextInt();
	switch(ch){
	
	
	case 1: //case1:
	    {
		/*System.out.println("Enter PurchaseId : ");
		int pId= sc.nextInt();*/
		System.out.println("Enter Customer Name : ");
		String cName= sc.next();
		System.out.println("Enter Email Id : ");
		String mailId= sc.next();
		System.out.println("Phone Number : ");
		String phone=sc.next();
		System.out.println("Mobile Id : ");
		int mId=sc.nextInt();
/*		System.out.println("Enter Purchase Date as : (dd-MM-yyyyy)");
		String dt= sc.next();
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate ed=LocalDate.parse(dt, formatter); */
	
		//Assign the user input values to setter(purchaseDetails = obj:purchase)
		//purchase.setPurchaseId(pId);
		purchase.setCname(cName);
		purchase.setMailId(mailId);
		purchase.setPhoneNo(phone);
		purchase.setMobileId(mId);
		//Add student to database..
		
		try {
			
			/*DataValidator validator= new DataValidator();
			boolean res= validator.validateInput(purchase);
			if(res){
			System.out.println(purchase.getCname());
			System.out.println(purchase.getMailId());
			System.out.println(purchase.getMobileId());
			System.out.println(purchase.getPhoneNo());*/
			
			PurchaseDetails s1=service.addDetails(purchase);
			logger.info("Student added to DB..."+purchase.getPurchaseId());
			System.out.println("Student added to DB..."+purchase.getPurchaseId());
			}
			
			 catch (MobileException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());}
		break;
	    } // case 1 closed
		
	      
	case 2:{
		
		System.out.println("Enter Mobile Id : ");
		int mobileId=sc.nextInt();
		System.out.println("Enter Quantity : ");
		int quantity=sc.nextInt();
		
		try {
			Mobiles s1=service.updateDetails(quantity, mobileId);
			if(s1.getMobileId()!=0)
				{
				logger.info("Mobiles updated ");
				System.out.println("Mobiles updated ");
				}
			else{
				logger.error("Mobile not found..!!!");
				System.out.println("Mobile not found..!!!");
		}} catch (MobileException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		
		break;
	}//case 2 closed
	
	case 3:{
		try {
			List<Mobiles> list=service.getMobileList();	
		    
		    if(list.size()==0)
		    {
		    	logger.error("No mobiles available...");
		    	System.out.println("No mobiles available...");
		    }else{
		    	for(Mobiles s: list){
		    		System.out.println(s.getMobileId()+" "+s.getName()+" "+ s.getQuantity()+" "+ s.getPrice());
		    	}
		    	
		    }
		    
		} catch (MobileException e) {
			logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
		
	}//case 3 closed
	
	case 4:{
		System.out.println("Enter Mobile Id : ");
		int mobileId=sc.nextInt();
		
		try {
			Mobiles s1=service.deleteDetails(mobileId);
			if(s1.getMobileId()!=0)
			{
				logger.info("Mobiles with mobileId = "+s1.getMobileId() +"deleted ");
				System.out.println("Mobiles with mobileId = "+s1.getMobileId() +"deleted ");
			}else
				logger.error("Mobile not found..!!!");
				System.out.println("Mobile not found..!!!");
		} catch (MobileException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		break;
	}//case 4 closed
	
	case 5:{
		
		    System.out.println("Min Price :");
		    int min=sc.nextInt();
		    System.out.println("Max Price :");
		    int max=sc.nextInt();
		    try {
				List<Mobiles> list=service.inBetween(min, max);

		    if(list.size()==0){
		    	logger.error("No. mobiles available...");
		    	System.out.println("No mobiles available...");
		    }
		    else{
		    	for(Mobiles s: list){
		    		System.out.println(s.getMobileId()+" "+s.getName()+" "+ s.getQuantity()+" "+ s.getPrice());
		    	}
		    	
		    }
		    
		} catch (MobileException e) {
		logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
	}//case 5 closed
	
	//default
	default:
		System.out.println("Enter correct choice");
	//default close
		
	}//switch closed
	
	
	}//main closed
	}//class closed
	

