package com.cg.exception;

public class EmployeeException extends Exception {
	public EmployeeException(String msg){
    	super(msg);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
