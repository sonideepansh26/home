package threeThree;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class DemoDate {
public void getDate(){
	DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MM/yyyy");
	System.out.println("Enter date in dd-MM-yyyy format");
	Scanner sc= new Scanner(System.in);
	String dateString=sc.next();
	System.out.println(dateString);
	 LocalDate date = LocalDate.parse(dateString, formatter);
	 LocalDate localdate= LocalDate.now();
	 System.out.println(localdate);
	 System.out.println("Duration between dates:");
	Period period =Period.between(date, localdate);
	System.out.println("Day:"+Math.abs(period.getDays())+" Month:"+Math.abs(period.getMonths())+" year:"+Math.abs(period.getYears()));
}
	


	public static void main(String[] args) throws ParseException {
		DemoDate dt= new DemoDate();
		dt.getDate();
	}

}
